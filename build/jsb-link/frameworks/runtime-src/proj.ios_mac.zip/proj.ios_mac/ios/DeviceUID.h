#import <Foundation/Foundation.h>

@interface DeviceUID : NSObject
+ (NSString *)uid;
@end
