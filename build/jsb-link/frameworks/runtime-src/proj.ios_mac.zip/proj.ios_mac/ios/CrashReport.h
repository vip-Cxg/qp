class CrashReport
{
public:

    static void reportException(const char* msg, const char* traceback);
    
    CrashReport();
};

